﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace HiRes.Infrastructure.Effects
{
	class BorderEffect : RoutingEffect
	{
		public BorderEffect() : base("Xamarin.BorderEffect")
		{
		}
	}
}
