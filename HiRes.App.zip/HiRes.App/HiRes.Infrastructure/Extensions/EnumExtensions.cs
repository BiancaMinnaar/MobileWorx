﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;


public static class EnumExtensions
{
	/// <summary>
	/// Gets the name.
	/// </summary>
	/// <param name="value">The value.</param>
	/// <returns></returns>
	public static string GetDescription(this Enum value)
	{
		if (value.ToString().Contains(","))
		{
			var item = value.ToString().Split(",".ToCharArray())[0];
			var firstEnumValue = Enum.Parse(value.GetType(), item);
			DescriptionAttribute[] descriptionAttributes = (DescriptionAttribute[])firstEnumValue.GetType().GetField(firstEnumValue.ToString()).GetCustomAttributes(typeof(DescriptionAttribute), false);
			return ((descriptionAttributes.Length > 0) ? descriptionAttributes[0].Description : firstEnumValue.ToString());
		}
		else
		{
			DescriptionAttribute[] descriptionAttributes = (DescriptionAttribute[])value.GetType().GetField(value.ToString()).GetCustomAttributes(typeof(DescriptionAttribute), false);
			return ((descriptionAttributes.Length > 0) ? descriptionAttributes[0].Description : value.ToString());
		}
	}

	/// <summary>
	/// Convert an Enumeration to list.
	/// </summary>
	/// <typeparam name="TEnum">The type of the enum.</typeparam>
	/// <returns>List of Anonymous Objects with a Name and Id Field</returns>
	public static List<object> EnumToList<TEnum>()
	{
		List<object> data = new List<object>();

		var values = Enum.GetValues(typeof(TEnum));
		foreach (Enum item in values)
		{
			var name = item.GetDescription();
			data.Add(new
			{
				Name = name,
				Id = item
			});
		}

		return data;
	}

	public static bool IsBitSet(this Enum value, Enum flagToCheckFor)
	{
		var result = (Convert.ToInt32(value) & Convert.ToInt32(flagToCheckFor)) == Convert.ToInt32(flagToCheckFor);

		return result;
	}
}
