﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HiRes.Infrastructure.Data
{
    public class PickerItem
    {
		public string Name { get; set; }
		public object Value { get; set; }
	}
}
