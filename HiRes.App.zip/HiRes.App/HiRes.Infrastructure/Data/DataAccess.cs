﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace HiRes.Infrastructure.Data
{
	class DataAccess
	{
		/// <summary>
		/// Example of how to use platform directives
		/// </summary>
		public static string DatabaseFilePath
		{
			get
			{
				
				var filename = "HiRes.db3";
#if SILVERLIGHT
    // Windows Phone 8
    var path = filename;
#else

#if __ANDROID__
				string libraryPath = Environment.GetFolderPath(Environment.SpecialFolder.Personal); ;
#else
#if __IOS__
        // we need to put in /Library/ on iOS5.1 to meet Apple's iCloud terms
        // (they don't want non-user-generated data in Documents)
        string documentsPath = Environment.GetFolderPath (Environment.SpecialFolder.Personal); // Documents folder
        string libraryPath = Path.Combine (documentsPath, "..", "Library");
#else
        // UWP
        string libraryPath = Windows.Storage.ApplicationData.Current.LocalFolder.Path;
#endif
#endif
				var path = Path.Combine(libraryPath, filename);
#endif
				return path;
			}
		}
	}
}
