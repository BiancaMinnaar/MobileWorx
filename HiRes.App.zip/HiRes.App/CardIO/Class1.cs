﻿using System;

namespace CardIO
{
    public class Class1
    {
    }
}
