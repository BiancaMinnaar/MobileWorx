﻿using System;
using System.Collections.Generic;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;

namespace HiRes.App.Services.CardIO
{
	interface ICardService
	{
		Task<CreditCardInfo> Run();

	}
}
