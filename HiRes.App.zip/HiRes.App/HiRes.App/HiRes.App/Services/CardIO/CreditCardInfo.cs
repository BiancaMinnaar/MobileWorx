﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HiRes.App.Services.CardIO
{
    public class CreditCardInfo
    {
		public string Name { get; set; }
		public int ExpiryMonth { get; set; }
		public int ExpiryYear { get; set; }
		public string CCV { get; set; }
		public string LastFourDigitsOfCardNumber { get; internal set; }
		public bool IsExpiryValid { get; internal set; }
		public string CardType { get; internal set; }
		public string CardNumber { get; internal set; }
		public string RedactedCardNumber { get; internal set; }
	}
}
