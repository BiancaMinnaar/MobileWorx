﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HiRes.App.Services
{
	public static class ResultContants
	{
		public static readonly int CARD_IO_RESULTS = 100;
	}
}
