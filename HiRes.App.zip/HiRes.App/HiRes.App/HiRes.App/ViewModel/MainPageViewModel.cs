﻿using HiRes.App.View.Registrations;
using HiRes.App.View.Residences;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Input;
using Xamarin.Forms;

namespace HiRes.App.ViewModel
{
	class MainPageViewModel : BaseViewModel
	{
		public ICommand RegisterStudentCommand;
		public ICommand ListResidencesCommand;
		public ICommand CaptureCreditCardInfoCommand;

		private readonly INavigation Navigation;

		public MainPageViewModel(INavigation navi)
		{
			Navigation = navi;

			RegisterStudentCommand = new Command(() =>
			{
				//MessagingCenter.Send<MainPageViewModel>(this, "Please open the Register Student page");
				Navigation.PushAsync(new NavigationPage(new RegistrationView()));
			});
			ListResidencesCommand = new Command(() =>
			{
				Navigation.PushAsync(new Residences_List_View());
			});

			CaptureCreditCardInfoCommand = new Command(() =>
		   {
			   Navigation.PushAsync(new View.Payments.ManualCaptureCreditCardView());
		   });
		}

	}
}
