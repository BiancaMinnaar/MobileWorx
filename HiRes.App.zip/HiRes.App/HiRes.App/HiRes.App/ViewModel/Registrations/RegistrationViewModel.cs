﻿using HiRes.App.Enumerations;
using HiRes.Infrastructure.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using System.Windows.Input;
using Xamarin.Forms;

namespace HiRes.App.ViewModel.Registrations
{
	public class RegistrationViewModel
	{
		public RegistrationViewModel()
		{
			Genders = EnumExtensions.EnumToList<GenderTypes>();
			CompleteRegistrationCommand = new Command(CompleteRegistration);
		}

		/// <summary>
		/// Name of the Person / Student registering
		/// </summary>
		[Required]
		public string Name { get; set; }

		/// <summary>
		/// Surname of the Person / Student registering
		/// </summary>
		[Required]
		public string Surname { get; set; }

		/// <summary>
		/// Gender property
		/// </summary>
		[Required]
		public GenderTypes Gender { get; set; }

		/// <summary>
		/// Genders used by the Dropdown (Picker)
		/// </summary>
		public List<object> Genders { get; set; }


		public string Nationality { get; set; }
		public string IDNumber { get; set; }
		public string MobileNumber { get; set; }
		public string EmailAddress { get; set; }
		public string ConfirmEmailAddress { get; set; }
		public DateTime BirthDate { get; set; } = new DateTime(DateTime.Today.Year, 1, 1).AddYears(-19);
		public string Password { get; set; }
		public string ConfirmPassword { get; set; }
		public string WhoReferedYou { get; set; }


		public ICommand CompleteRegistrationCommand { get; set; }


		private void CompleteRegistration()
		{
			App.GetMainPage().DisplayAlert("Hello", "From the Other Side", "OK");
		}
	}
}
