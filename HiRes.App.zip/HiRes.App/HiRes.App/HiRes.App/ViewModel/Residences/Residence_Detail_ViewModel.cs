﻿using HiRes.App.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace HiRes.App.ViewModel.Residences
{
	public class Residence_Detail_ViewModel
	{
		public Residence Residence { get; set; }

		public Residence_Detail_ViewModel(Residence residence)
		{
			this.Residence = residence;
		}

	}
}
