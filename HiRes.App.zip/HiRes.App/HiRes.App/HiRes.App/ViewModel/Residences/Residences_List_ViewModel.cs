﻿using HiRes.App.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace HiRes.App.ViewModel.Residences
{
	public class Residences_List_ViewModel
	{
		public List<Residence> Residences { get; set; }

		public Residences_List_ViewModel()
		{
			this.Residences = MakeSomeExampleResidences();
		}

		private List<Residence> MakeSomeExampleResidences()
		{
			// TODO: test-code remove once actual API-based implementation is done?
			var result = new List<Residence>{

				#region saratoga village
				new Residence { Name = "SARATOGA VILLAGE",City="JOHANNESBURG",
					Summary ="Saratoga Village is perfectly situated in Doornfontein right across the road from the University of Johannesburg. With the Doornfontein Campus bus stop on our doorstep, we can also be home to WITS, CJC, UJ Auckland Park and Soweto Campus students",
					CoverImageResource = "saratoga-village-cover-300x300",
					CarouselImageResources = new List<string> { "saratoga-village-slider-01", "saratoga-village-slider-02", "saratoga-village-slider-03" } ,
					MapImageResource = "saratoga-village-map",
					ClosestCampus="University of Johannesburg(DFC) and WITS",
					Tribe="Saratoga Chiefs",
					Capacity ="1134 students",
					Address ="13 Saratoga Avenue, Johannesburg",
					AppartmentOptions ="6 and 8 bed apartments",
					ContactNumber ="011404 5001/2",
					HeadOfficeNumber ="0100 200 300",
					DistanceHeader ="DISTANCE FROM UJ (DFC) / WITS",
					DistanceInfo ="On Campus / 2.7 km",
					WriteUp = "Forge your own way; carve out your own path; set your own boundaries. As you pioneer towards your future, come and discover why over a thousand students have chosen Saratoga Village – the largest res in the Respublica family."
						+Environment.NewLine+Environment.NewLine+"Arguably one of the most stylish student residences in the country, Saratoga Village offers you modern, apartment style living with a fitness centre, swimming pool and computer lab. What’s more, when you join the Saratoga Chiefs you’ll get in on all our social and networking events and meet all the other Respublicans across South Africa."
						+Environment.NewLine+Environment.NewLine+"You’ll have easy access to UJ and WITS through the Rea Vaya stop on your doorstep or the private bus service for the off-campus students.Ask your res manager for the cost of this monthly ticket.",
					LoungeInfo = "Inspiring spaces to work and play",
					SecurityInfo = "State of the art security",
					RulesInfo = "Strictly enforced house rules. No drama!",
					WaterAndLightsInfo = "Water and electricity costs are included",
					SocialInfo = "Jam packed res-life programme including sports, academic support, socials and so much more",
					BedroomInfo = "Single and shared rooms in each apartment",
					BathroomInfo = "Apartments have their own kitchens and bathrooms",
					KitchenInfo = "The kitchen has a 4-plate stove, fridge and microwave",
					SleepingArrangementInfo = "Each bedroom has a bed, a real spring mattress (none of that sponge nonsense) with cover, large clothing cupboard, desk, chair, book shelf and pin board",
					CleaningInfo = "Weekly cleaning",
					CanteenInfo = "All you need to bring is linen, crockery & cutlery, and cooking utensils",
					WifiInfo = "Uncapped wireless internet throughout the res!",
					ComputerLabInfo = "Computer Lab",
					TvInfo = "TV rooms",
					StudyInfo = "Study rooms with individual desks",
					GamesRoomInfo = "Games rooms with pool tables",
					GymInfo = "Fully equipped gym",
					SwimmingInfo = "Outdoor swimming pool",
					ShopInfo = "Onsite convenience grocery store",
					ParkingInfo = "Free parking",
					BraaiInfo = "",
				},
				#endregion

				#region yale village
				new Residence { Name="YALE VILLAGE",City="JOHANNESBURG",
					CoverImageResource = "yale-village-cover-300x300" ,
					CarouselImageResources = new List<string> { "yale-village-slider-01", "yale-village-slider-02", "yale-village-slider-03", "yale-village-slider-04", "yale-village-slider-05" },
				},
				#endregion

				#region the fields
				new Residence { Name="THE FIELDS",City="JOHANNESBURG",
					CoverImageResource = "the-fields-cover-300x300",
					CarouselImageResources = new List<string> { "the-fields-slider-01", "the-fields-slider-02", "the-fields-slider-03" },
				}, 
				#endregion

				#region eastwood willage
				new Residence { Name="EASTWOOD VILLAGE",City="PRETORIA",
					CoverImageResource = "eastwood-village-cover-300x300",
					CarouselImageResources = new List<string> { "eastwood-village-slider-01", "eastwood-village-slider-02", "eastwood-village-slider-03" },
				},
				#endregion

				#region west city
				new Residence { Name="WEST CITY",City="PRETORIA"
					,CoverImageResource = "west-city-cover-300x300",
					CarouselImageResources = new List<string> { "west-city-slider-01", "west-city-slider-02", "west-city-slider-03" },
				},
				#endregion

				#region hatfield square
				new Residence { Name="HATFIELD SQUARE",City="PRETORIA",
					CoverImageResource = "hatfield-square-cover-300x300",
					CarouselImageResources = new List<string> { "hatfield-square-slider-01", "hatfield-square-slider-02", "hatfield-square-slider-03", "hatfield-square-slider-04", "hatfield-square-slider-05" },
				},
				#endregion

				#region urban nest
				new Residence { Name="URBAN NEST",City="PRETORIA",
					CoverImageResource = "urban-nest-cover-300x300",
					CarouselImageResources = new List<string> { "urban-nest-slider-01", "urban-nest-slider-02", "urban-nest-slider-03" },
				},
				#endregion

				#region princeton house
				new Residence { Name="PRINCETON HOUSE",City="MIDRAND",
					CoverImageResource = "princeton-house-cover-300x300",
					CarouselImageResources = new List<string> { "princeton-house-slider-01", "princeton-house-slider-02", "princeton-house-slider-03", "princeton-house-slider-04", "princeton-house-slider-05" },
				},
				#endregion

				#region lincoln house
				new Residence { Name="LINCOLN HOUSE",City="BLOEMFONTEIN",
					CoverImageResource = "lincoln-house-cover-300x300",
					CarouselImageResources = new List<string> { "lincoln-house-slider-01", "lincoln-house-slider-02", "lincoln-house-slider-03", "lincoln-house-slider-04", "lincoln-house-slider-05" , "lincoln-house-slider-06" },
				},
				#endregion

				#region sample res
				new Residence { Name="TEST RES",City="Imaginary City",
					Summary ="Example Residence with nearly no facilities",
					CoverImageResource = "default-cover",
					CarouselImageResources = new List<string> { "default-slider" },
					LoungeInfo = "",
					SecurityInfo = "",
					RulesInfo = "",
					WaterAndLightsInfo = "",
					SocialInfo = "",
					BedroomInfo = "",
					BathroomInfo = "",
					KitchenInfo = "",
					SleepingArrangementInfo = "",
					CleaningInfo = "",
					CanteenInfo = "",
					WifiInfo = "The only thing we have is WIFI",
					ComputerLabInfo = "",
					TvInfo = "",
					StudyInfo = "",
					GamesRoomInfo = "",
					GymInfo = "",
					SwimmingInfo = "",
					ShopInfo = "",
					ParkingInfo = "and Free parking",
					BraaiInfo = "and a Braai"
				},
				#endregion
			};
			while (result.Count < 15)
			{
				result.Add(new Residence());
			}
			var i = 0;
			foreach (var entry in result)
			{
				i++;
				var type = entry.GetType();
				var props = type.GetProperties();
				foreach (var prop in props)
				{
					switch (prop.Name)
					{
						case "Name":
							if (string.IsNullOrWhiteSpace(entry.Name))
							{
								entry.Name = $"Residence {i}";
							}
							break;
						case "CoverImageResource":
							if (string.IsNullOrWhiteSpace(entry.CoverImageResource))
							{
								entry.CoverImageResource = "default-cover";
							}
							break;
						case "CarouselImageResources":
							if (entry.CarouselImageResources == null)
							{
								entry.CarouselImageResources = new List<string> { "default-slider" };
							}
							break;
						default:
							if ((prop.CanWrite) && (prop.PropertyType == typeof(String)))
							{
								string currentValue = (string)prop.GetValue(entry);
								if (currentValue == null)
								{
									string displayName = null;
									var dnProps = prop.GetCustomAttributes(typeof(DisplayNameAttribute), false);
									if (dnProps.Length > 0)
									{
										var dn = dnProps[0] as DisplayNameAttribute;
										if (dn != null)
										{
											displayName = dn.DisplayName;
										}
									}
									if (string.IsNullOrWhiteSpace(displayName))
									{
										displayName = prop.Name;
									}
									prop.SetValue(entry, string.Format("Example {0} value", displayName));
								}
							}
							break;
					}

				}
			}

			return result;
		}
	}
}
