﻿using System;

namespace HiRes.App.Enumerations
{
	[Flags]
	public enum GenderTypes
	{
		Male = 1,
		Female = 2,
		Unknown = 4
	}
}