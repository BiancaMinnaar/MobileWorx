﻿using HiRes.App.Enumerations;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HiRes.App.Model
{
	class Registration
	{
		public string Name { get; set; }
		public string Surname { get; set; }
		public GenderTypes Gender { get; set; }
		public string Nationality { get; set; }
		public string IDNumber { get; set; }
		public string MobileNumber { get; set; }
		[Display(Name = "Email address")]
		public string EmailAddress { get; set; }
		[Display(Name = "Confirm Email address")]
		public string ConfirmEmailAddress { get; set; }
		[Display(Name = "Birthday")]
		public DateTime BirthDate { get; set; }
		public string Password { get; set; }
		[Display(Name = "Confirm password")]
		public string ConfirmPassword { get; set; }
		[Display(Name = "Who referred you?")]
		public string WhoReferredYou { get; set; }
	}
}
