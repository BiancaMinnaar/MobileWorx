﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

using Xamarin;
using Xamarin.Forms;

namespace HiRes.App.Model
{
	public class Residence
	{
		public ImageSource Image
		{
			get
			{
				var result = ImageSource.FromResource(CoverImageResource);
				return result;
			}
		}

		// TODO: cleanup this hack for show and tell
		public ImageSource CarouselImage
		{
			get
			{
				if ((CarouselImageResources != null) && (CarouselImageResources.Count > 0))
				{
					var result = ImageSource.FromResource(CarouselImageResources[0]);
					return result;
				}
				return null;
			}
		}

		public ImageSource MapImage
		{
			get
			{
				var result = ImageSource.FromResource(MapImageResource);
				return result;
			}
		}

		[DisplayName("Name")]
		public string Name { get; set; }
		[DisplayName("City")]
		public string City { get; set; }

		public string NameCityCombo { get { return $"{Name} - {City}"; } }

		public string CoverImageResource { get; set; }
		[DisplayName("Summary")]
		public string Summary { get; set; }

		public string BannerImageResource { get; set; }

		[DisplayName("About")]
		public string WriteUp { get; set; }  // TODO: turn this into a List<string> of paragraphs (HtmlString?) decide on where/and how this will all be populated

		[DisplayName("Closest Campus")]
		public string ClosestCampus { get; set; }
		[DisplayName("Capacity")]
		public string Capacity { get; set; }
		[DisplayName("Address")]
		public string Address { get; set; }
		[DisplayName("Tribe")]
		public string Tribe { get; set; }
		[DisplayName("Appartment Options")]
		public string AppartmentOptions { get; set; }
		[DisplayName("Contact Number")]
		public string ContactNumber { get; set; }
		[DisplayName("Head Office")]
		public string HeadOfficeNumber { get; set; }

		public string CarouselTag { get; set; }

		public List<string> CarouselImageResources { get; set; }
		public List<string> ThreeSixtyResources { get; set; }
		public List<string> VideoResources { get; set; }

		[DisplayName("Lounge")]
		public string LoungeInfo { get; set; }
		[DisplayName("Canteen")]
		public string CanteenInfo { get; set; }
		[DisplayName("Security")]
		public string SecurityInfo { get; set; }
		[DisplayName("Biometrics")]
		public string BiometricInfo { get; set; }
		[DisplayName("WI-FI")]
		public string WifiInfo { get; set; }
		//[DisplayName("Printing")]
		//public string PrintingInfo { get; set; }
		[DisplayName("Rules")]
		public string RulesInfo { get; set; }
		[DisplayName("Computer Lab")]
		public string ComputerLabInfo { get; set; }
		[DisplayName("Water & lights")]
		public string WaterAndLightsInfo { get; set; }
		[DisplayName("TV")]
		public string TvInfo { get; set; }
		[DisplayName("Social")]
		public string SocialInfo { get; set; }
		[DisplayName("Study")]
		public string StudyInfo { get; set; }
		[DisplayName("Games Room")]
		public string GamesRoomInfo { get; set; }
		[DisplayName("Bedrooms")]
		public string BedroomInfo { get; set; }
		[DisplayName("Bathrooms")]
		public string BathroomInfo { get; set; }
		[DisplayName("Gym")]
		public string GymInfo { get; set; }
		[DisplayName("Swimming")]
		public string SwimmingInfo { get; set; }
		[DisplayName("Shop")]
		public string ShopInfo { get; set; }
		[DisplayName("Kitchen")]
		public string KitchenInfo { get; set; }
		[DisplayName("Cleaning")]
		public string CleaningInfo { get; set; }
		[DisplayName("Sleeping Arrangements")]
		public string SleepingArrangementInfo { get; set; }
		[DisplayName("Parking")]
		public string ParkingInfo { get; set; }

		[DisplayName("Braai")]
		public string BraaiInfo{ get; set; }

		public string DistanceHeader { get; set; }
		public string DistanceInfo { get; set; }
		public string DirectionsLink { get; set; }
		public string MapImageResource { get; set; }

		public List<string> ImageGalleryResources { get; set; }

	}
}
