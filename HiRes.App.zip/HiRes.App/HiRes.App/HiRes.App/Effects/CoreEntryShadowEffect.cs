﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace HiRes.App.Effects
{
	public class CoreEntryShadowEffect : RoutingEffect
	{
		public float Radius { get; set; }

		public Color Color { get; set; }

		public float DistanceX { get; set; }

		public float DistanceY { get; set; }

		public CoreEntryShadowEffect() : base("HiRes.App.EntryShadowEffect")
		{
		}
	}
}
