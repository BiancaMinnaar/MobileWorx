﻿using HiRes.App.View.Registrations;
using HiRes.App.View.Residences;
using HiRes.Infrastructure.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

using Xamarin.Forms;

namespace HiRes.App
{
	public partial class App : Application
	{
		INavigationService navigationService;

		public App()
		{
			InitializeComponent();
			InitializeServices();

			//
			MainPage = GetMainPage();

			AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;
		}

		private void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
		{
			GetMainPage().DisplayAlert("Error", e.ExceptionObject.ToString(), "Cancel");
		}

		public static Page GetMainPage()
		{
			return new NavigationPage(new MainPage());
		}

		void InitializeServices()
		{
			navigationService = new NavigationService();
			((NavigationService)navigationService).RegisterPage("MainPage", () => new MainPage());
			((NavigationService)navigationService).RegisterPage("RegistrationView", () => new RegistrationView());
			((NavigationService)navigationService).RegisterPage("Residences_List_View", () => new Residences_List_View());

			//ViewModelLocator.Register(typeof(FirstPage).ToString(), () => new FirstPageViewModel(navigationService));
			//ViewModelLocator.Register(typeof(SecondPage).ToString(), () => new SecondPageViewModel(navigationService));
		}


		/*
public static Page GetMainPage(string accessToken, string deviceIdentifier, string username)
{
     if (!string.IsNullOrEmpty(accessToken))
     {
          SSO.MyAuthentication client = new SSO.MyAuthentication(deviceIdentifier);

          bool validToken = client.IsValidToken(accessToken, username);

          if (validToken) _ReturnPage = new HomePage(); else _ReturnPage = new LoginPage(deviceIdentifier);
     }
     else
     {
         _ReturnPage = new LoginPage(deviceIdentifier);
     }

     **return new NavigationPage(_ReturnPage);**
}		 */

		protected override void OnStart()
		{
			// Handle when your app starts
		}

		protected override void OnSleep()
		{
			// Handle when your app sleeps
		}

		protected override void OnResume()
		{
			// Handle when your app resumes
		}


	}
}
