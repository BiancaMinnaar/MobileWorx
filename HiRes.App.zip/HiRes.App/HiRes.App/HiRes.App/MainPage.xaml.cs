﻿using HiRes.App.View.Maps;
using HiRes.App.View.Registrations;
using HiRes.App.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace HiRes.App
{
	public partial class MainPage : ContentPage
	{
		MainPageViewModel vm = null;

		public MainPage()
		{
			vm = new MainPageViewModel(Navigation);
			InitializeComponent();
			BindingContext = vm;
		}

		private void Button_Clicked(object sender, EventArgs e)
		{
			//vm.RegisterStudentCommand.Execute(null);
			vm.CaptureCreditCardInfoCommand.Execute(null);
		}

		private void RegisterStudent_Clicked(object sender, EventArgs e)
		{
			vm.RegisterStudentCommand.Execute(null);
		}

		private void Button_Residences_Clicked(object sender, EventArgs e)
		{
			vm.ListResidencesCommand.Execute(null);
		}

		private async void btnShowLocation_Clicked(object sender, EventArgs e)
		{
			await Navigation.PushAsync(new LocationView());
		}
	}
}
