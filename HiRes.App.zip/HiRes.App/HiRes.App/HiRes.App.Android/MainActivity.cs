﻿using System;

using Android.App;
using Android.Content.PM;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Android.Content;
using HiRes.App.Droid.Services.CardIO;
using Card.IO;
using HiRes.App.Services.CardIO;
using System.Threading.Tasks;

namespace HiRes.App.Droid
{
	[Activity(Label = "HiRes.App", Icon = "@drawable/icon", Theme = "@style/MainTheme", MainLauncher = true, ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
	public class MainActivity : global::Xamarin.Forms.Platform.Android.FormsAppCompatActivity
	{
		internal static Context CurrentContext { get; private set; }
		public TaskCompletionSource<CreditCardInfo> CardIO_TaskCompletionSource { set; get; }

		protected override void OnCreate(Bundle bundle)
		{
			TabLayoutResource = Resource.Layout.Tabbar;
			ToolbarResource = Resource.Layout.Toolbar;

			CurrentContext = this;

			base.OnCreate(bundle);
			global::Xamarin.FormsGoogleMaps.Init(this, bundle);
			global::Xamarin.Forms.Forms.Init(this, bundle);
			LoadApplication(new App());
		}

		protected override void OnActivityResult(int requestCode, Result resultCode, Intent data)
		{
			if (requestCode == HiRes.App.Services.ResultContants.CARD_IO_RESULTS)
				ProcessCardIoResults(resultCode, data);

			base.OnActivityResult(requestCode, resultCode, data);
		}

		private void ProcessCardIoResults(Result resultCode, Intent data)
		{

			if (resultCode == Result.Canceled)
				CardIO_TaskCompletionSource.SetCanceled();
			else if (resultCode == Result.Ok || (int)resultCode == 13274384)
			{
				if (data != null)
				{
					var card = data.GetParcelableExtra(CardIOActivity.ExtraScanResult).JavaCast<CreditCard>();

					var info = new CreditCardInfo();
					info.CCV = card.Cvv;
					info.ExpiryMonth = card.ExpiryMonth;
					info.ExpiryYear = card.ExpiryYear;
					info.RedactedCardNumber = card.RedactedCardNumber;
					info.CardNumber = card.CardNumber;
					info.Name = card.CardholderName;
					info.CardType = card.CardType.Name;
					info.IsExpiryValid = card.IsExpiryValid;
					info.LastFourDigitsOfCardNumber = card.LastFourDigitsOfCardNumber;

					CardIO_TaskCompletionSource.SetResult(info);
				}
				else
					CardIO_TaskCompletionSource.SetException(new ArgumentNullException("Data was null from Card IO"));
			}
			else
				CardIO_TaskCompletionSource.SetException(new NotSupportedException($"Result code from Intent was '{resultCode}' not supported"));

		}




		public void OnActivityCreated(Activity activity, Bundle savedInstanceState)
		{
			CurrentContext = activity;
		}

		public void OnActivityResumed(Activity activity)
		{
			CurrentContext = activity;
		}

		public void OnActivityStarted(Activity activity)
		{
			CurrentContext = activity;
		}
	}
}

