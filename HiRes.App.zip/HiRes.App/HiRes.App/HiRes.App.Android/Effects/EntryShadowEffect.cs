﻿using HiRes.App.Droid.Effects;
using HiRes.App.Effects;
using System;
using System.Linq;
using Xamarin.Forms;
using Xamarin.Forms.Platform.Android;

[assembly: ResolutionGroupName("HiRes")]
[assembly: ExportEffect(typeof(EntryShadowEffect), "EntryShadowEffect")]
namespace HiRes.App.Droid.Effects
{
	public class EntryShadowEffect : PlatformEffect
	{
		protected override void OnAttached()
		{
			try
			{

				var control = Control as Android.Widget.TextView;
				var effect = (CoreEntryShadowEffect)Element.Effects.FirstOrDefault(e => e is CoreEntryShadowEffect);
				if (effect != null)
				{
					float radius = effect.Radius;
					float distanceX = effect.DistanceX;
					float distanceY = effect.DistanceY;
					Android.Graphics.Color color = effect.Color.ToAndroid();
					control.SetShadowLayer(radius, distanceX, distanceY, color);
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Cannot set property on attached control. Error: ", ex.Message);
			}
		}

		protected override void OnDetached()
		{
		}
	}
}