﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Card.IO;
using HiRes.App.Services;
using HiRes.App.Services.CardIO;
using Xamarin.Forms;

[assembly: Dependency(typeof(HiRes.App.Droid.Services.CardIO.CardIOService))]
namespace HiRes.App.Droid.Services.CardIO
{
	class CardIOService : Java.Lang.Object, ICardService
	{
		private Activity activity = null;
		private TaskCompletionSource<CreditCardInfo> taskCompletion = null;

		private void InitCardService()
		{
			// Init current activity
			activity = MainActivity.CurrentContext as Activity;

			if (activity == null)
				throw new NullReferenceException("Current Context is not of type Activity!!!");
		}

		/// <summary>
		/// Run the Card.IO activity
		/// </summary>
		/// <returns></returns>
		public Task<CreditCardInfo> Run()
		{
			taskCompletion = new TaskCompletionSource<CreditCardInfo>();

			InitCardService();
			var intent = new Intent(activity, typeof(CardIOActivity));
			intent.PutExtra(CardIOActivity.ExtraRequireExpiry, true);
			intent.PutExtra(CardIOActivity.ExtraRequireCvv, true);
			intent.PutExtra(CardIOActivity.ExtraRequirePostalCode, false);
			intent.PutExtra(CardIOActivity.ExtraRequireCardholderName, true);
			intent.PutExtra(CardIOActivity.ExtraUseCardioLogo, false);

			activity.StartActivityForResult(intent, ResultContants.CARD_IO_RESULTS);

			((MainActivity)activity).CardIO_TaskCompletionSource = taskCompletion;

			return taskCompletion.Task;
		}

	}
}