﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using HiRes.App.Droid.Renderers;
using Xamarin.Forms;
using Xamarin.Forms.Platform.Android;

[assembly: ExportRenderer(typeof(Xamarin.Forms.Button), typeof(CoreButtonRenderer))]
namespace HiRes.App.Droid.Renderers
{
	public class CoreButtonRenderer : ButtonRenderer
	{
		public CoreButtonRenderer(Context context) : base(context)
		{
		}

		protected override void OnElementChanged(ElementChangedEventArgs<Xamarin.Forms.Button> e)
		{
			base.OnElementChanged(e);
			if (Control != null)
			{
				//Control.SetBackgroundColor(global::HiRes.App.App.Current.Resources[""]); //Android.Graphics.Color.LightGreen);
			}
		}
	}

	//public class MyEntryRenderer : ButtonRenderer
	//{
	//	protected override void OnElementChanged(ElementChangedEventArgs<Entry> e)
	//	{
	//		base.OnElementChanged(e);

	//		if (Control != null)
	//		{
	//			Control.SetBackgroundColor(global::Android.Graphics.Color.LightGreen);
	//		}
	//	}
	//}
}